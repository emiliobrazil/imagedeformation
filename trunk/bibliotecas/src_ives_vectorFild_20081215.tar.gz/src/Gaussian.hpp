#ifndef __GAUSSIAN_HPP__

    #define __GAUSSIAN_HPP__

    #include <cmath>

    template < typename real, unsigned int n >
    class Gaussian {


        public:
            Gaussian(void);
            virtual ~Gaussian(void);

            virtual real operator()(
                const real point[n],
                const real center[n],
                const real radius
            ) const;

    };

    template < typename real, unsigned int n >
    Gaussian<real,n>::Gaussian(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    Gaussian<real,n>::~Gaussian(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    real Gaussian<real,n>::operator()(const real point[n],
            const real center[n], const real radius) const {
        static const real sqrtTwoPi = 2.5066282746310002f;
        real vector[n];
        cppblas_copy(n, point, 1, vector, 1);
        cppblas_axpy(n, -1, center, 1, vector, 1);
        real tSqr = cppblas_dot(n, vector, 1, vector, 1) / (radius * radius);
        return std::exp(-0.5 * tSqr) / (radius * sqrtTwoPi);
    }

#endif  // __GAUSSIAN_HPP__
