#ifndef __KERNEL_HPP__

    #define __KERNEL_HPP__

    template < typename real, unsigned int n >
    class Kernel {


        protected:
            Kernel(void) {}

        public:
            virtual ~Kernel(void) {}

            virtual real operator()(
                const real point[n],
                const real center[n],
                const real radius
            ) const = 0;

    };

#endif  // __KERNEL_HPP__
