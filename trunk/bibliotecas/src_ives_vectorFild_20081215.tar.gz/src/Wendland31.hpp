#ifndef __WENDLAND31_HPP__

    #define __WENDLAND31_HPP__

    template < typename real, unsigned int n >
    class Wendland31 {


        public:
            Wendland31(void);
            virtual ~Wendland31(void);

            virtual real operator()(
                const real point[n],
                const real center[n],
                const real radius
            ) const;

    };

    template < typename real, unsigned int n >
    Wendland31<real,n>::Wendland31(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    Wendland31<real,n>::~Wendland31(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    real Wendland31<real,n>::operator()(const real point[n],
            const real center[n], const real radius) const {
        real ret = 0;
        real vector[n];
        cppblas_copy(n, point, 1, vector, 1);
        cppblas_axpy(n, -1, center, 1, vector, 1);
        real r = cppblas_nrm2(n, vector, 1);

        if (r < radius) {
            r /= radius;
            real omr1 = 1 - r;
            real omr2 = omr1 * omr1;
            real omr4 = omr2 * omr2;
            ret = omr4 * (1 + 4 * r);
        }

        return ret;
    }

#endif  // __WENDLAND31_HPP__
