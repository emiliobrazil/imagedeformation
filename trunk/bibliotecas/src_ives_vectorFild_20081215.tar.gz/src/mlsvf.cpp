#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

#include <cstdlib>
#include <cstring>

#include <iostream>
#include <vector>

#include "mlsvf.hpp"

///////////////////////////////////////////////////////////////////////////////

#define MIN(x,y)     (((x)<(y))?(x):(y))
#define MAX(x,y)     (((x)>(y))?(x):(y))
#define CLAMP(x,m,M) (((x)<(m))?(m):(((x)>(M))?(M):(x)))

#define FOR_EACH_CELL   for(i=1;i<=N;++i){for(j=1;j<=N;++j){
#define END_FOR_EACH    }}

const int DEFAULT_WINDOW_WIDTH  = 768;
const int DEFAULT_WINDOW_HEIGHT = 768;

const char DEFAULT_WINDOW_NAME[]  = "ivex::mlsvf::window";
const char DEFAULT_WINDOW_TITLE[] = "MLS-based Vector Field Reconstruction";

///////////////////////////////////////////////////////////////////////////////

typedef double real;
const unsigned int n = 2;

typedef Wendland31<real,n> kernel;
// typedef Gaussian<real,n> kernel;
// typedef ConstantMLSVF<real,n,kernel> vector_field;
// typedef LinearMLSVF<real,n,kernel> vector_field;
typedef DivLinearMLSVF<real,n,kernel> vector_field;
// typedef FourVortices<real> vector_field;
// typedef FourSources<real> vector_field;
// typedef FourGaussians<real> vector_field;

typedef enum _display_e {
    DISPLAY_SAMPLES,
    DISPLAY_VELOCITIES
} display_e;

///////////////////////////////////////////////////////////////////////////////

int screenWidth, screenHeight;
int windowWidth, windowHeight;
int windowX, windowY;
int window;

bool clicked[3];
int sx, tx, sy, ty;

display_e displayMode = DISPLAY_SAMPLES;

unsigned int resolution = 64;

vector_field f;

std::vector<real> xSamples, ySamples, uSamples, vSamples;
real bDiv = 0;

bool needReevaluation = false;
bool needPassSamples = false;

real *up = NULL;
real *vp = NULL;

///////////////////////////////////////////////////////////////////////////////

void setViewport(int width, int height) {
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glViewport(0, 0, width, height);
}

void setProjection(int width, int height) {
    float m = MIN(width,height);
    float w = width  / m;
    float h = height / m;
    float gapW = ( w - 1.0f ) / 2.0f;
    float gapH = ( h - 1.0f ) / 2.0f;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D( -gapW, 1.0f + gapW, -gapH, 1.0f + gapH );
}

void displayBoundary(void) {
    glColor3f(0.5f, 0.5f, 0.5f);
    glLineWidth(1.0f);
    glBegin(GL_LINE_LOOP);
        glVertex2f(0.0f, 0.0f);
        glVertex2f(0.0f, 1.0f);
        glVertex2f(1.0f, 1.0f);
        glVertex2f(1.0f, 0.0f);
    glEnd();
}

void displayCellCenters(void) {
    unsigned int i, j, N = resolution;
    float x, y;

    glColor3f(0.0f, 0.0f, 1.0f);
    glPointSize(2.0f);
    glBegin(GL_POINTS);
        FOR_EACH_CELL
            x = ( i - 0.5f ) / N;
            y = ( j - 0.5f ) / N;
            glVertex2f(x, y);
        END_FOR_EACH
    glEnd();
}

void updateSamples(void) {
    unsigned int numberOfSamples = xSamples.size();

    real* points = new real[2 * numberOfSamples];
    real* vectors = new real[2 * numberOfSamples];

    for (register unsigned int i = 0; i < numberOfSamples; ++i) {
        points[2*i  ] = xSamples[i];
        points[2*i+1] = ySamples[i];
        vectors[2*i  ] = uSamples[i];
        vectors[2*i+1] = vSamples[i];
    }

    f.setSamples(numberOfSamples, points, vectors);

    delete[] vectors;
    delete[] points;
}

void updateGrid(void) {
    unsigned int i, j, N = resolution;
    real point[n], vector[n];

    FOR_EACH_CELL
        point[0] = ( i - 0.5f ) / N;
        point[1] = ( j - 0.5f ) / N;
// std::cout << "Evaluating sample..." << std::endl;
        f.evaluate(point, vector);
// std::cout << "Sample evaluated!!!" << std::endl;
        up[(j-1) + (i-1) * N] = vector[0];
        vp[(j-1) + (i-1) * N] = vector[1];
    END_FOR_EACH
}

void displayVelocities(void) {
    unsigned int i, j, N = resolution;
    real x, y, u, v;

    if ((displayMode == DISPLAY_VELOCITIES) && needReevaluation) {

        if (needPassSamples) {
//             std::cout << "Updating samples..." << std::endl;
            updateSamples();
//             std::cout << "Samples updated!!!" << std::endl;
            needPassSamples = false;
        }

//         std::cout << "Updating grid..." << std::endl;
        updateGrid();
//         std::cout << "Grid updated!!!" << std::endl;
        needReevaluation = false;
    }

    glColor3f(1.0f, 0.0f, 0.0f);
    glLineWidth(1.0f);
    glBegin(GL_LINES);
        FOR_EACH_CELL
            x = ( i - 0.5f ) / N;
            y = ( j - 0.5f ) / N;
            u = up[(j-1) + (i-1) * N];
            v = vp[(j-1) + (i-1) * N];
// std::cout << "f(" << x << ',' << y << ") = (" << u << ',' << v << ')' << std::endl;
            glVertex2f(x, y);
            glVertex2f(x + u, y + v);
        END_FOR_EACH
    glEnd();
}

void displaySamples(void) {
    displayBoundary();
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glColor3f(1.0f, 0.0f, 0.0f);
    glPointSize(5.0f);
    glBegin(GL_POINTS);
        for (register unsigned int i = 0; i < xSamples.size(); ++i) {
            glVertex2f(xSamples[i], ySamples[i]);
        }
    glEnd();
    glColor3f(0.0f, 0.0f, 1.0f);
    glLineWidth(3.0f);
    glBegin(GL_LINES);
        for (register unsigned int i = 0; i < uSamples.size(); ++i) {
            glVertex2f(xSamples[i]            , ySamples[i]            );
            glVertex2f(xSamples[i]+uSamples[i], ySamples[i]+vSamples[i]);
        }
    glEnd();
}

void displayVelocityField(void) {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    displayBoundary();
    displayCellCenters();
    displayVelocities();
}

void display(void) {
    glClear(GL_COLOR_BUFFER_BIT);

    setProjection(windowWidth, windowHeight);
    setViewport(windowWidth, windowHeight);

    if (displayMode == DISPLAY_SAMPLES) {
        displaySamples();
    } else if (displayMode == DISPLAY_VELOCITIES) {
        displayVelocityField();
    }

    glutSwapBuffers();
}

void reshape(int width, int height) {
    windowWidth  = width;
    windowHeight = height;

    glutSetWindow(window);
    glutReshapeWindow(windowWidth, windowHeight);

    setProjection(windowWidth, windowHeight);
    setViewport(windowWidth, windowHeight);

    glutPostRedisplay();
}

void resetGrid(void) {
    unsigned int size = resolution * resolution;

    if (up != NULL) {
        std::memset(up, 0, size * sizeof(real));
    }

    if (vp != NULL) {
        std::memset(vp, 0, size * sizeof(real));
    }

}

void resizeGrid(void) {
    unsigned int size = resolution * resolution;

    if (up != NULL) {
        delete[] up;
        up = NULL;
    }

    if (vp != NULL) {
        delete[] vp;
        vp = NULL;
    }

    up = new real[size];
    vp = new real[size];
    resetGrid();
}

void keyboard(unsigned char key, int x, int y) {

    switch(key) {
        case 'h':
        case 'H':
            resolution *= 2;
            resizeGrid();
            needReevaluation = true;
            break;
        case 'l':
        case 'L':
            resolution /= 2;
            if (resolution < 2) {
                resolution = 2;
            } else {
                resizeGrid();
                needReevaluation = true;
            }
            break;
        case ']':
            f.setRadius(f.getRadius() * 2);
            std::cout << "f.getRadius() = " << f.getRadius() << std::endl;
            needReevaluation = true;
            break;
        case '[':
            f.setRadius(f.getRadius() / 2);
            std::cout << "f.getRadius() = " << f.getRadius() << std::endl;
            needReevaluation = true;
            break;
        case 'd':
        case 'D':
            if (displayMode == DISPLAY_SAMPLES) {
                displayMode = DISPLAY_VELOCITIES;
            } else if (displayMode == DISPLAY_VELOCITIES) {
                displayMode = DISPLAY_SAMPLES;
            }
            break;
        case 'q':
        case 'Q':
        case  27:
            exit(EXIT_SUCCESS);
            break;
        case 'c':
        case 'C':
            xSamples.clear();
            ySamples.clear();
            uSamples.clear();
            vSamples.clear();
            f.clear();
            resetGrid();
            break;
    }

}

void mouse(int button, int state, int x, int y) {
    sx = tx = x;
    sy = ty = y;
    clicked[button] = ( state == GLUT_DOWN );
}

void motion(int x, int y) {
    tx = x;
    ty = y;
}

void special(int key, int x, int y) {

}

void readUserInput(void) {
    int minDimension = MIN(windowWidth,windowHeight);
    int gapW = ( windowWidth  - minDimension ) / 2;
    int gapH = ( windowHeight - minDimension ) / 2;

    if ( clicked[0] || clicked[2] ) {
        float s =        (((float)(tx-gapW)) / ((float)(minDimension)));
        float t = 1.0f - (((float)(ty-gapH)) / ((float)(minDimension)));

        if ( (0.0f <= s) && (s <= 1.0f) && (0.0f <= t) && (t <= 1.0f) ) {
            real x, y, u, v;
            x = s;
            y = t;
            u = static_cast<real>(tx - sx) / windowWidth;
            v = static_cast<real>(sy - ty) / windowHeight;

            if (clicked[0]) {
                xSamples.push_back(x);
                ySamples.push_back(y);
                uSamples.push_back(u);
                vSamples.push_back(v);
                needReevaluation = true;
                needPassSamples = true;
            }

            if (clicked[2]) {

            }

            sx = tx;
            sy = ty;
        }

    }

}

void idle(void) {
    readUserInput();

    glutSetWindow( window );
    glutPostRedisplay();
}

///////////////////////////////////////////////////////////////////////////////

void initialize(int* argcp, char* argv[]) {
    glutInit(argcp, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
    screenWidth  = glutGet(GLUT_SCREEN_WIDTH);
    screenHeight = glutGet(GLUT_SCREEN_HEIGHT);
    windowWidth  = MIN(DEFAULT_WINDOW_WIDTH, screenWidth);
    windowHeight = MIN(DEFAULT_WINDOW_HEIGHT, screenHeight);
    windowX = (screenWidth - windowWidth) / 2;
    windowY = (screenHeight - windowHeight) / 2;
    glutInitWindowSize(windowWidth, windowHeight);
    glutInitWindowPosition(windowX, windowY);

    clicked[0] = clicked[1] = clicked[2] = false;
    sx = tx = sy = ty = 0;

    resizeGrid();
    f.setRadius(0.125f);
}

void setup(int* argcp, char* argv[]) {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
/*    glEnable(GL_POINT_SMOOTH);*/
/*    glEnable(GL_LINE_SMOOTH);*/
    glShadeModel(GL_SMOOTH);
/*    glShadeModel(GL_FLAT);*/

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutSpecialFunc(special);
    glutIdleFunc(idle);
}

void start(int* argcp, char* argv[]) {
    window = glutCreateWindow(DEFAULT_WINDOW_NAME);
    glutSetWindow(window);
    glutSetWindowTitle(DEFAULT_WINDOW_TITLE);
    glutShowWindow();
    glutSetCursor(GLUT_CURSOR_FULL_CROSSHAIR);
    setup(argcp, argv);
    glutMainLoop();
}

int finalize(void) {

    if (up != NULL) {
        delete[] up;
        up = NULL;
    }

    if (vp != NULL) {
        delete[] vp;
        vp = NULL;
    }

    glutDestroyWindow(window);
    return EXIT_SUCCESS;
}

int main(int argc, char* argv[]) {
    initialize(&argc, argv);
    start(&argc, argv);
    return finalize();
}
