#ifndef __CONSTANTMLSVF_HPP__

    #define __CONSTANTMLSVF_HPP__

    #include <cstddef>
    #include <cfloat>

    #include "VectorField.hpp"

    #include "cppblas.hpp"

    template < typename real, unsigned int n, class Kernel >
    class ConstantMLSVF : public VectorField<real,n> {


        protected:
            unsigned int numberOfSamples;
            real* points;
            real* vectors;

            Kernel kernel;
            real radius;

        public:
            ConstantMLSVF(void);
            ConstantMLSVF(const ConstantMLSVF<real,n,Kernel>& vf);
            virtual ~ConstantMLSVF(void);

            unsigned int getNumberOfSamples(void) const;
            void getPoints(real* points) const;
            void getVectors(real* vectors) const;

            void setSamples(unsigned int numberOfSamples,
                const real* points, const real* vectors);

            real getRadius(void) const;
            void setRadius(const real radius);

            virtual void evaluate(
                const real point[n],
                real vector[n]
            ) const;

            void clear(void);

            virtual ConstantMLSVF<real,n,Kernel>& operator=(
                const ConstantMLSVF<real,n,Kernel>& vf
            );

    };

    template < typename real, unsigned int n, class Kernel >
    ConstantMLSVF<real,n,Kernel>::ConstantMLSVF(void) {
        this->numberOfSamples = 0;
        this->points = NULL;
        this->vectors = NULL;
        this->radius = 1;
    }

    template < typename real, unsigned int n, class Kernel >
    ConstantMLSVF<real,n,Kernel>::ConstantMLSVF(
            const ConstantMLSVF<real,n,Kernel>& vf
    ) {
        (*this) = vf;
    }

    template < typename real, unsigned int n, class Kernel >
    ConstantMLSVF<real,n,Kernel>::~ConstantMLSVF(void) {
        this->clear();
    }

    template < typename real, unsigned int n, class Kernel >
    unsigned int ConstantMLSVF<real,n,Kernel>::getNumberOfSamples(void) const {
        return this->numberOfSamples;
    }

    template < typename real, unsigned int n, class Kernel >
    void ConstantMLSVF<real,n,Kernel>::getPoints(real* points) const {
        cppblas_copy(n * this->numberOfSamples, this->points, 1, points, 1);
    }

    template < typename real, unsigned int n, class Kernel >
    void ConstantMLSVF<real,n,Kernel>::getVectors(real* vectors) const {
        cppblas_copy(n * this->numberOfSamples, this->vectors, 1, vectors, 1);
    }

    template < typename real, unsigned int n, class Kernel >
    void ConstantMLSVF<real,n,Kernel>::setSamples(unsigned int numberOfSamples,
            const real* points, const real* vectors) {
        this->clear();
        this->numberOfSamples = numberOfSamples;
        this->points = new real[n * this->numberOfSamples];
        this->vectors = new real[n * this->numberOfSamples];
        cppblas_copy(n * this->numberOfSamples, points, 1, this->points, 1);
        cppblas_copy(n * this->numberOfSamples, vectors, 1, this->vectors, 1);
    }

    template < typename real, unsigned int n, class Kernel >
    real ConstantMLSVF<real,n,Kernel>::getRadius(void) const {
        return this->radius;
    }

    template < typename real, unsigned int n, class Kernel >
    void ConstantMLSVF<real,n,Kernel>::setRadius(const real radius) {
        this->radius = radius;
    }

    template < typename real, unsigned int n, class Kernel >
    void ConstantMLSVF<real,n,Kernel>::evaluate(const real point[n],
            real vector[n]) const {
        static const real EPSILON = FLT_EPSILON;
        real weightSum = 0;
        cppatlas_set(n, 0, vector, 1);

        for (register unsigned int i = 0; i < this->numberOfSamples; ++i) {
            real weight = kernel(&this->points[n * i], point, this->radius);

            if (weight > 0) {
                weightSum += weight;
                cppblas_axpy(n, weight, &this->vectors[n * i], 1, vector, 1);
            }

        }

        if (weightSum > EPSILON) {
            cppblas_scal(n, 1 / weightSum, vector, 1);
        }

    }

    template < typename real, unsigned int n, class Kernel >
    void ConstantMLSVF<real,n,Kernel>::clear(void) {

        if (this->vectors != NULL) {
            delete[] this->vectors;
            this->vectors = NULL;
        }

        if (this->points != NULL) {
            delete[] this->points;
            this->points = NULL;
        }

        if (this->numberOfSamples > 0) {
            this->numberOfSamples = 0;
        }

    }

    template < typename real, unsigned int n, class Kernel >
    ConstantMLSVF<real,n,Kernel>& ConstantMLSVF<real,n,Kernel>::operator=(
            const ConstantMLSVF<real,n,Kernel>& vf
    ) {
        this->setSamples(vf.numberOfSamples, vf.points, vf.vectors);
        this->radius = vf.radius;
        return (*this);
    }

#endif  // __CONSTANTMLSVF_HPP__
