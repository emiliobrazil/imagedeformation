#ifndef __CONSTANTVF_HPP__

    #define __CONSTANTVF_HPP__

    #include "VectorField.hpp"

    #include "cppblas.hpp"

    template < typename real, unsigned int n >
    class ConstantVF : public VectorField<real,n> {


        protected:
            real c[n];

        public:
            ConstantVF(void);
            ConstantVF(const real c[n]);
            ConstantVF(const ConstantVF<real,n>& vf);
            virtual ~ConstantVF(void);

            void getC(real c[n]) const;
            void setC(const real c[n]);

            virtual void evaluate(
                const real point[n],
                real vector[n]
            ) const;

            virtual ConstantVF<real,n>& operator=(
                const ConstantVF<real,n>& vf
            );

    };

    template < typename real, unsigned int n >
    ConstantVF<real,n>::ConstantVF(void) {
        cppatlas_set(n, 0, this->c, 1);
    }

    template < typename real, unsigned int n >
    ConstantVF<real,n>::ConstantVF(const real c[n]) {
        this->setC(c);
    }

    template < typename real, unsigned int n >
    ConstantVF<real,n>::ConstantVF(const ConstantVF<real,n>& vf) {
        (*this) = vf;
    }

    template < typename real, unsigned int n >
    ConstantVF<real,n>::~ConstantVF(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    void ConstantVF<real,n>::getC(real c[n]) const {
        cppblas_copy(n, this->c, 1, c, 1);
    }

    template < typename real, unsigned int n >
    void ConstantVF<real,n>::setC(const real c[n]) {
        cppblas_copy(n, c, 1, this->c, 1);
    }

    template < typename real, unsigned int n >
    void ConstantVF<real,n>::evaluate(const real point[n],
            real vector[n]) const {
        cppblas_copy(n, this->c, 1, vector, 1);
    }

    template < typename real, unsigned int n >
    ConstantVF<real,n>& ConstantVF<real,n>::operator=(
            const ConstantVF<real,n>& vf
    ) {
        this->setC(vf.c);
        return (*this);
    }

#endif  // __CONSTANTVF_HPP__
