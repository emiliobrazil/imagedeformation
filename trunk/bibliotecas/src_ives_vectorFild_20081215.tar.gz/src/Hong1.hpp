#ifndef __HONG1_HPP__

    #define __HONG1_HPP__

    template < typename real, unsigned int n >
    class Hong1 {


        protected:
            real epsilon;

        public:
            Hong1(const real epsilon = 1e-4);
            virtual ~Hong1(void);

            virtual real operator()(
                const real point[n],
                const real center[n],
                const real radius
            ) const;

    };

    template < typename real, unsigned int n >
    Hong1<real,n>::Hong1(const real epsilon) {
        this->epsilon = epsilon;
    }

    template < typename real, unsigned int n >
    Hong1<real,n>::~Hong1(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    real Hong1<real,n>::operator()(const real point[n],
            const real center[n], const real radius) const {
        real vector[n];
        cppblas_copy(n, point, 1, vector, 1);
        cppblas_axpy(n, -1, center, 1, vector, 1);
        real rSqr = cppblas_dot(n, vector, 1, vector, 1);
        rSqr /= radius * radius;
        real epsilonSqr = epsilon * epsilon;
        return (1 / (rSqr + epsilonSqr));
    }

#endif  // __HONG1_HPP__
