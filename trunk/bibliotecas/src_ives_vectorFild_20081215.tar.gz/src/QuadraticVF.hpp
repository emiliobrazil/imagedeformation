#ifndef __QUADRATICVF_HPP__

    #define __QUADRATICVF_HPP__

    #include "VectorField.hpp"

    #include "cppblas.hpp"

    template < typename real, unsigned int n >
    class QuadraticVF : public VectorField<real,n> {


        protected:
            real a[n][n][n];
            real b[n][n];
            real c[n];

        public:
            QuadraticVF(void);
            QuadraticVF(const real a[n][n][n],
                    const real b[n][n], const real c[n]);
            QuadraticVF(const QuadraticVF<real,n>& vf);
            virtual ~QuadraticVF(void);

            void getA(real a[n][n][n]) const;
            void setA(const real a[n][n][n]);

            void getB(real b[n][n]) const;
            void setB(const real b[n][n]);

            void getC(real c[n]) const;
            void setC(const real c[n]);

            virtual void evaluate(
                const real point[n],
                real vector[n]
            ) const;

            virtual QuadraticVF<real,n>& operator=(
                const QuadraticVF<real,n>& vf
            );

    };

    template < typename real, unsigned int n >
    QuadraticVF<real,n>::QuadraticVF(void) {
        cppatlas_set(n * n * n, 0, (real*)this->a, 1);
        cppatlas_set(n * n, 0, (real*)this->b, 1);
        cppatlas_set(n, 0, this->c, 1);
    }

    template < typename real, unsigned int n >
    QuadraticVF<real,n>::QuadraticVF(const real a[n][n][n],
            const real b[n][n], const real c[n]) {
        this->setA(a);
        this->setB(b);
        this->setC(c);
    }

    template < typename real, unsigned int n >
    QuadraticVF<real,n>::QuadraticVF(const QuadraticVF<real,n>& vf) {
        (*this) = vf;
    }

    template < typename real, unsigned int n >
    QuadraticVF<real,n>::~QuadraticVF(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    void QuadraticVF<real,n>::getA(real a[n][n][n]) const {
        cppblas_copy(n * n * n, (real*)this->a, 1, (real*)a, 1);
    }

    template < typename real, unsigned int n >
    void QuadraticVF<real,n>::setA(const real a[n][n][n]) {
        cppblas_copy(n * n * n, (real*)a, 1, (real*)this->a, 1);
    }

    template < typename real, unsigned int n >
    void QuadraticVF<real,n>::getB(real b[n][n]) const {
        cppblas_copy(n * n, (real*)this->b, 1, (real*)b, 1);
    }

    template < typename real, unsigned int n >
    void QuadraticVF<real,n>::setB(const real b[n][n]) {
        cppblas_copy(n * n, (real*)b, 1, (real*)this->b, 1);
    }

    template < typename real, unsigned int n >
    void QuadraticVF<real,n>::getC(real c[n]) const {
        cppblas_copy(n, this->c, 1, c, 1);
    }

    template < typename real, unsigned int n >
    void QuadraticVF<real,n>::setC(const real c[n]) {
        cppblas_copy(n, c, 1, this->c, 1);
    }

    template < typename real, unsigned int n >
    void QuadraticVF<real,n>::evaluate(const real point[n],
            real vector[n]) const {
        cppblas_copy(n, this->c, 1, vector, 1);
        cppblas_gemv(CblasRowMajor, CblasNoTrans,
            n, n, 1, (real*)this->b, n, point, 1, 1, vector, 1);

        for (register unsigned int i = 0; i < n; ++i) {
            real u[n];
            cppblas_gemv(CblasRowMajor, CblasNoTrans,
                n, n, 0.5, (real*)this->a[i], n, point, 1, 0, u, 1);
            vector[i] += cppblas_dot(n, point, 1, u, 1);
        }

    }

    template < typename real, unsigned int n >
    QuadraticVF<real,n>& QuadraticVF<real,n>::operator=(
            const QuadraticVF<real,n>& vf
    ) {
        this->setA(vf.a);
        this->setB(vf.b);
        this->setC(vf.c);
        return (*this);
    }

#endif  // __QUADRATICVF_HPP__
