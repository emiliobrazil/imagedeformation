#ifndef __FOURSOURCES_HPP__

    #define __FOURSOURCES_HPP__

    #include <cmath>

    #include "VectorField.hpp"

    #include "cppblas.hpp"

    template < typename real >
    class FourSources : public VectorField<real,2> {


        public:
            FourSources(void);
            virtual ~FourSources(void);

            virtual void evaluate(
                const real point[2],
                real vector[2]
            ) const;

        private:
            real gaussian(const real point[2], const real mu[2],
                const real sigma) const;
            void addGaussianGrad(const real scale, const real point[2],
                const real mu[2], const real sigma, real vector[2]) const;

    };

    template < typename real >
    FourSources<real>::FourSources(void) {
        // Do nothing...
    }

    template < typename real >
    FourSources<real>::~FourSources(void) {
        // Do nothing...
    }

    template < typename real >
    void FourSources<real>::evaluate(const real point[2],real vector[2])const{
        real mu[2], sigma = 1.0f / 9.0f;
        cppatlas_set(2, 0, vector, 1);
//         mu[0] =  0.25f; mu[1] =  0.00f;
//         this->addGaussianGrad(-0.25f, point, mu, sigma, vector);
//         mu[0] =  0.00f; mu[1] =  0.25f;
//         this->addGaussianGrad( 0.25f, point, mu, sigma, vector);
//         mu[0] = -0.25f; mu[1] =  0.00f;
//         this->addGaussianGrad(-0.25f, point, mu, sigma, vector);
//         mu[0] =  0.00f; mu[1] = -0.25f;
//         this->addGaussianGrad( 0.25f, point, mu, sigma, vector);
        mu[0] =  0.75f; mu[1] =  0.50f;
        this->addGaussianGrad(-0.00048828125f, point, mu, sigma, vector);
        mu[0] =  0.50f; mu[1] =  0.75f;
        this->addGaussianGrad( 0.00048828125f, point, mu, sigma, vector);
        mu[0] =  0.25f; mu[1] =  0.50f;
        this->addGaussianGrad(-0.00048828125f, point, mu, sigma, vector);
        mu[0] =  0.50f; mu[1] =  0.25f;
        this->addGaussianGrad( 0.00048828125f, point, mu, sigma, vector);
    }

    template < typename real >
    real FourSources<real>::gaussian(const real point[2], const real mu[2],
        const real sigma) const {
        static const real sqrtTwoPi = 2.5066282746310002f;
        real vector[2];
        cppblas_copy(2, point, 1, vector, 1);
        cppblas_axpy(2, -1, mu, 1, vector, 1);
        real tSqr = cppblas_dot(2, vector, 1, vector, 1) / (sigma * sigma);
        return std::exp(-0.5 * tSqr) / (sigma * sqrtTwoPi);
    }

    template < typename real >
    void FourSources<real>::addGaussianGrad(const real scale,
            const real point[2], const real mu[2], const real sigma,
            real vector[2]) const {
        real scalar = - scale * gaussian(point, mu, sigma) / (sigma * sigma);
        real temp[2];
        cppblas_copy(2, point, 1, temp, 1);
        cppatlas_axpby(2, -scalar, mu, 1, scalar, temp, 1);
        cppblas_axpy(2, 1, temp, 1, vector, 1);
    }

#endif  // __FOURSOURCES_HPP__
