#ifndef __HONG3_HPP__

    #define __HONG3_HPP__

    template < typename real, unsigned int n >
    class Hong3 {


        protected:
            real epsilon;

        public:
            Hong3(const real epsilon = 1e-4);
            virtual ~Hong3(void);

            virtual real operator()(
                const real point[n],
                const real center[n],
                const real radius
            ) const;

    };

    template < typename real, unsigned int n >
    Hong3<real,n>::Hong3(const real epsilon) {
        this->epsilon = epsilon;
    }

    template < typename real, unsigned int n >
    Hong3<real,n>::~Hong3(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    real Hong3<real,n>::operator()(const real point[n],
            const real center[n], const real radius) const {
        real vector[n];
        cppblas_copy(n, point, 1, vector, 1);
        cppblas_axpy(n, -1, center, 1, vector, 1);
        real rSqr = cppblas_dot(n, vector, 1, vector, 1);
        rSqr /= radius * radius;
        real r4 = rSqr * rSqr;
        real r8 = r4 * r4;
        real epsilonSqr = epsilon * epsilon;
        return (1 / (r8 + epsilonSqr));
    }

#endif  // __HONG3_HPP__
