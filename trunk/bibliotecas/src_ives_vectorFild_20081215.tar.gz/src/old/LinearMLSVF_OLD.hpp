#ifndef __LINEARMLSVF_HPP__

    #define __LINEARMLSVF_HPP__

    #include <cstddef>

    #include "VectorField.hpp"
    #include "LinearVF.hpp"

    #include "cppblas.hpp"
    #include "cpplapack.hpp"

    template < typename real, unsigned int n, class Kernel >
    class LinearMLSVF : public VectorField<real,n> {


        protected:
            unsigned int numberOfSamples;
            real* points;
            real* vectors;

            Kernel kernel;
            real radius;

            real regularization;

        private:
            real* weights;
            unsigned int* nnzI;

        public:
            LinearMLSVF(void);
            LinearMLSVF(const LinearMLSVF<real,n,Kernel>& vf);
            virtual ~LinearMLSVF(void);

            unsigned int getNumberOfSamples(void) const;
            void getPoints(real* points) const;
            void getVectors(real* vectors) const;

            void setSamples(unsigned int numberOfSamples,
                const real* points, const real* vectors);

            real getRadius(void) const;
            void setRadius(const real radius);

            real getRegularization(void) const;
            void setRegularization(const real regularization);

            virtual void evaluate(
                const real point[n],
                LinearVF<real,n>& cvf
            ) const;

            virtual void evaluate(
                const real point[n],
                real vector[n]
            ) const;

            void clear(void);

            virtual LinearMLSVF<real,n,Kernel>& operator=(
                const LinearMLSVF<real,n,Kernel>& vf
            );

    };

    template < typename real, unsigned int n, class Kernel >
    LinearMLSVF<real,n,Kernel>::LinearMLSVF(void) {
        this->numberOfSamples = 0;
        this->points = NULL;
        this->vectors = NULL;
        this->radius = 1;
        this->regularization = 1;
        this->weights = NULL;
        this->nnzI = NULL;
    }

    template < typename real, unsigned int n, class Kernel >
    LinearMLSVF<real,n,Kernel>::LinearMLSVF(
            const LinearMLSVF<real,n,Kernel>& vf
    ) {
        (*this) = vf;
    }

    template < typename real, unsigned int n, class Kernel >
    LinearMLSVF<real,n,Kernel>::~LinearMLSVF(void) {
        this->clear();
    }

    template < typename real, unsigned int n, class Kernel >
    unsigned int LinearMLSVF<real,n,Kernel>::getNumberOfSamples(void) const {
        return this->numberOfSamples;
    }

    template < typename real, unsigned int n, class Kernel >
    void LinearMLSVF<real,n,Kernel>::getPoints(real* points) const {
        cppblas_copy(n * this->numberOfSamples, this->points, 1, points, 1);
    }

    template < typename real, unsigned int n, class Kernel >
    void LinearMLSVF<real,n,Kernel>::getVectors(real* vectors) const {
        cppblas_copy(n * this->numberOfSamples, this->vectors, 1, vectors, 1);
    }

    template < typename real, unsigned int n, class Kernel >
    void LinearMLSVF<real,n,Kernel>::setSamples(unsigned int numberOfSamples,
            const real* points, const real* vectors) {
        this->clear();
        this->numberOfSamples = numberOfSamples;
        this->points = new real[n * this->numberOfSamples];
        this->vectors = new real[n * this->numberOfSamples];
        cppblas_copy(n * this->numberOfSamples, points, 1, this->points, 1);
        cppblas_copy(n * this->numberOfSamples, vectors, 1, this->vectors, 1);
        this->weights = new real[this->numberOfSamples];
        this->nnzI = new unsigned int[this->numberOfSamples];
    }

    template < typename real, unsigned int n, class Kernel >
    real LinearMLSVF<real,n,Kernel>::getRadius(void) const {
        return this->radius;
    }

    template < typename real, unsigned int n, class Kernel >
    void LinearMLSVF<real,n,Kernel>::setRadius(const real radius) {
        this->radius = radius;
    }

    template < typename real, unsigned int n, class Kernel >
    real LinearMLSVF<real,n,Kernel>::getRegularization(void) const {
        return this->regularization;
    }

    template < typename real, unsigned int n, class Kernel >
    void LinearMLSVF<real,n,Kernel>::setRegularization(
            const real regularization) {
        this->regularization = regularization;
    }

//     template < typename real, unsigned int n, class Kernel >
//     void LinearMLSVF<real,n,Kernel>::evaluate(const real point[n],
//             LinearVF<real,n>& lvf) const {
//         real c[n], b[n][n];
//         cppatlas_set(n, 0, c, 1);
//         cppatlas_set(n * n, 0, (real*)b, 1);
//
//         real weightSum = 0;
//         real xBar[n], yBar[n];
//         cppatlas_set(n, 0, xBar, 1);
//         cppatlas_set(n, 0, yBar, 1);
//
//         unsigned int nnz = 0, *nnzI = new unsigned int[this->numberOfSamples];
//         real *weights = new real[this->numberOfSamples];
//
//         for (register unsigned int i = 0, j = 0; i < this->numberOfSamples; ++i) {
//             weights[j] = kernel(&this->points[n * i], point, this->radius);
//
//             if (weights[j] > 0) {
//                 nnzI[j++] = i;
//                 weightSum += weights[j];
//                 cppblas_axpy(n, weights[j], &this->points[n * i], 1, xBar, 1);
//                 cppblas_axpy(n, weights[j], &this->vectors[n * i], 1, yBar, 1);
//             }
//
//         }
//
//         if (weightSum > 0) {
//             cppblas_scal(n, 1 / weightSum, yBar, 1);
//             cppblas_copy(n, yBar, 1, c, 1);
//
//             if (nnz >= 2*n) {
//                 cppblas_scal(n, 1 / weightSum, xBar, 1);
//                 real xxBar[n][n], yxBar[n][n];
//                 cppatlas_set(n * n, 0, (real*)xxBar, 1);
//                 cppatlas_set(n * n, 0, (real*)yxBar, 1);
//                 real x[n], y[n];
//
//                 for (register unsigned int i = 0; i < nnz; ++i) {
//                     cppblas_copy(n, &this->points[n * nnzI[i]], 1, x, 1);
//                     cppblas_axpy(n, -1, xBar, 1, x, 1);
//                     cppblas_copy(n, &this->vectors[n * nnzI[i]], 1, y, 1);
//                     cppblas_axpy(n, -1, yBar, 1, y, 1);
//                     cppblas_ger(CblasRowMajor, n, n, weights[i], x, 1, x, 1, (real*)xxBar, n);
//                     cppblas_ger(CblasRowMajor, n, n, weights[i], y, 1, x, 1, (real*)yxBar, n);
//                 }
//
//                 cpplapack_posv(CblasColMajor, CblasUpper, n, n, (real*)xxBar, n, (real*)yxBar, n);
//                 cppblas_copy(n * n, (real*)yxBar, 1, (real*)b, 1);
//                 cppblas_gemv(CblasRowMajor, CblasNoTrans,
//                     n, n, -1, (real*)b, n, xBar, 1, 1, c, 1);
//             }
//
//         }
//
//         delete[] weights;
//         weights = NULL;
//
//         delete[] nnzI;
//         nnzI = NULL;
//
//         lvf.setC(c);
//         lvf.setB(b);
//     }

    template < typename real, unsigned int n, class Kernel >
    void LinearMLSVF<real,n,Kernel>::evaluate(const real point[n],
            LinearVF<real,n>& lvf) const {
        real c[n], b[n][n];
        cppatlas_set(n, 0, c, 1);
        cppatlas_set(n * n, 0, (real*)b, 1);

        real weightSum = 0;
        real xBar[n], yBar[n];
        cppatlas_set(n, 0, xBar, 1);
        cppatlas_set(n, 0, yBar, 1);

        unsigned int nnz = 0;

        for (register unsigned int i = 0; i < this->numberOfSamples; ++i) {
            real weight = kernel(&this->points[i * n], point, this->radius);

            if (weight > 0) {
                this->nnzI[nnz] = i;
                this->weights[nnz] = weight;
                ++nnz;

                weightSum += weight;
                cppblas_axpy(n, weight, &this->points[i * n], 1, xBar, 1);
                cppblas_axpy(n, weight, &this->vectors[i * n], 1, yBar, 1);
            }

        }

        if (nnz > 0) {
            cppblas_scal(n, 1 / weightSum, xBar, 1);
            cppblas_scal(n, 1 / weightSum, yBar, 1);

            if (nnz >= n) {
                real x[n], y[n], xxBar[n][n], xyBar[n][n];
                cppatlas_set(n * n, 0, (real*)xxBar, 1);
                cppatlas_set(n * n, 0, (real*)xyBar, 1);

                for (register unsigned int i = 0; i < nnz; ++i) {
                    cppblas_copy(n, &this->points[this->nnzI[i] * n], 1, x, 1);
                    cppblas_copy(n, &this->vectors[this->nnzI[i] * n], 1, y, 1);
                    cppblas_axpy(n, -1, xBar, 1, x, 1);
                    cppblas_axpy(n, -1, yBar, 1, y, 1);
                    cppblas_ger(CblasRowMajor, n, n,
                        this->weights[this->nnzI[i]],
                        x, 1, x, 1, (real*)xxBar, n);
                    cppblas_ger(CblasRowMajor, n, n,
                        this->weights[this->nnzI[i]],
                        x, 1, y, 1, (real*)xyBar, n);
                }

                cppblas_copy(n * n, (real*)xxBar, 1, (real*)b, 1);
                int code = cpplapack_potrf(CblasRowMajor,
                    CblasUpper, n, (real*)xxBar, n);

                if (code != 0) {
                    cppblas_copy(n * n, (real*)b, 1, (real*)xxBar, 1);
//                     real traceXX = cppblas_asum(n, (real*)xxBar, n);

                    for (register unsigned int i = 0; i < n; ++i) {
/*                        xxBar[i][i] += this->regularization * traceXX;*/
                        xxBar[i][i] += this->regularization;
                    }

                    cpplapack_potrf(CblasRowMajor,
                        CblasUpper, n, (real*)xxBar, n);
                }

                cpplapack_potrs(CblasRowMajor, CblasUpper,
                    n, n, (real*)xxBar, n, (real*)xyBar, n);
/*                cpplapack_potri(CblasRowMajor, CblasUpper, n, (real*)xxBar, n);
                real traceXX = 0, traceXY = 0;

                for (register unsigned int i = 0; i < n; ++i) {
                    traceXX += xxBar[i][i];
                    traceXY += xyBar[i][i];
                }

                real lambda = (this->divBeta - traceXY) / traceXX;
                cppblas_axpy(n * n, lambda, (real*)xxBar, 1, (real*)xyBar, 1);
*/
                for (register unsigned int i = 0; i < n; ++i) {

                    for (register unsigned int j = 0; j < n; ++j) {
                        b[i][j] = xyBar[j][i];
                    }

                }

                cppblas_copy(n, yBar, 1, c, 1);
                cppblas_gemv(CblasRowMajor, CblasNoTrans,
                    n, n, -1, (real*)b, n, xBar, 1, 1, c, 1);
            } else {
                cppblas_copy(n, yBar, 1, c, 1);
            }

        }

        lvf.setC(c);
        lvf.setB(b);
    }

    template < typename real, unsigned int n, class Kernel >
    void LinearMLSVF<real,n,Kernel>::evaluate(const real point[n],
            real vector[n]) const {
        LinearVF<real,n> lvf;
        this->evaluate(point, lvf);
        lvf.evaluate(point, vector);
    }

    template < typename real, unsigned int n, class Kernel >
    void LinearMLSVF<real,n,Kernel>::clear(void) {

        if (this->nnzI != NULL) {
            delete[] this->nnzI;
            this->nnzI = NULL;
        }

        if (this->weights != NULL) {
            delete[] this->weights;
            this->weights = NULL;
        }

        if (this->vectors != NULL) {
            delete[] this->vectors;
            this->vectors = NULL;
        }

        if (this->points != NULL) {
            delete[] this->points;
            this->points = NULL;
        }

        if (this->numberOfSamples > 0) {
            this->numberOfSamples = 0;
        }

    }

    template < typename real, unsigned int n, class Kernel >
    LinearMLSVF<real,n,Kernel>& LinearMLSVF<real,n,Kernel>::operator=(
            const LinearMLSVF<real,n,Kernel>& vf
    ) {
        this->setSamples(vf.numberOfSamples, vf.points, vf.vectors);
        this->radius = vf.radius;
        this->regularization = vf.regularization;
        return (*this);
    }

#endif  // __LINEARMLSVF_HPP__
