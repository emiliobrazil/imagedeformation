#include <cstdlib>

#include "mlsvf.hpp"

typedef double real;
const unsigned int n = 2;

int main(int argc, char* argv[]) {
    return EXIT_SUCCESS;
}
