#include <iostream>
#include <cstdlib>

#include "cppblas.hpp"

#include "VectorField.hpp"
#include "ConstantVF.hpp"
#include "LinearVF.hpp"
#include "QuadraticVF.hpp"

typedef double real;
const unsigned int n = 2;

int main(int argc, char* argv[]) {
    real c[n] = {0,1};
    real b[n][n] = {{0,1},{2,3}};
    real a[n][n][n] = {{{0,1},{2,3}},{{4,5},{6,7}}};
    real point[n] = {1,1};
    real vector[n] = {0,0};
    QuadraticVF<real,n>* qvf = new QuadraticVF<real,n>();
    VectorField<real,n>* vf = qvf;
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << c[i] << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            std::cerr << b[i][j] << ' ';
        }
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            for (register unsigned int k = 0; k < n; ++k) {
                std::cerr << a[i][j][k] << ' ';
            }
        }
    }
    std::cerr << std::endl;
    qvf->setC(c);
    qvf->setB(b);
    qvf->setA(a);
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << c[i] << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            std::cerr << b[i][j] << ' ';
        }
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            for (register unsigned int k = 0; k < n; ++k) {
                std::cerr << a[i][j][k] << ' ';
            }
        }
    }
    std::cerr << std::endl;
    cppatlas_set(n * n * n, 0, (real*)a, 1);
    cppatlas_set(n * n, 0, (real*)b, 1);
    cppatlas_set(n, 0, c, 1);
//     qvf->setC(c);
//     qvf->setB(b);
//     qvf->setA(a);
    vf->evaluate(point,vector);
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << c[i] << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            std::cerr << b[i][j] << ' ';
        }
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            for (register unsigned int k = 0; k < n; ++k) {
                std::cerr << a[i][j][k] << ' ';
            }
        }
    }
    std::cerr << std::endl;
    qvf->getC(c);
    qvf->getB(b);
    qvf->getA(a);
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << c[i] << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            std::cerr << b[i][j] << ' ';
        }
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            for (register unsigned int k = 0; k < n; ++k) {
                std::cerr << a[i][j][k] << ' ';
            }
        }
    }
    std::cerr << std::endl;
    real *tmpA = (real*)a, *tmpB = (real*)b, *tmpC = (real*)c;
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << *(tmpC++) << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n * n; ++i) {
        std::cerr << *(tmpB++) << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n * n * n; ++i) {
        std::cerr << *(tmpA++) << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << vector[i] << ' ';
    }
    std::cerr << std::endl;
    delete qvf;
    return EXIT_SUCCESS;
}
