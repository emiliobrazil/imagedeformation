#include <iostream>
#include <cstdlib>

typedef double real;
const unsigned int n = 2;

int main(int argc, char* argv[]) {
    real a[n][n][n], b[n][n], c[n];
    register unsigned int counterA = 0, counterB = 0, counterC = 0;
    for (register unsigned int i = 0; i < n; ++i) {
        c[i] = counterC++;
        for (register unsigned int j = 0; j < n; ++j) {
            b[i][j] = counterB++;
            for (register unsigned int k = 0; k < n; ++k) {
                a[i][j][k] = counterA++;
            }
        }
    }
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << c[i] << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            std::cerr << b[i][j] << ' ';
        }
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        for (register unsigned int j = 0; j < n; ++j) {
            for (register unsigned int k = 0; k < n; ++k) {
                std::cerr << a[i][j][k] << ' ';
            }
        }
    }
    std::cerr << std::endl;
    real *tmpA = (real*)a, *tmpB = (real*)b, *tmpC = (real*)c;
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << tmpC[i] << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n * n; ++i) {
        std::cerr << tmpB[i] << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n * n * n; ++i) {
        std::cerr << tmpA[i] << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n; ++i) {
        std::cerr << *tmpC++ << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n * n; ++i) {
        std::cerr << *tmpB++ << ' ';
    }
    std::cerr << std::endl;
    for (register unsigned int i = 0; i < n * n * n; ++i) {
        std::cerr << *tmpA++ << ' ';
    }
    std::cerr << std::endl;
    return EXIT_SUCCESS;
}
