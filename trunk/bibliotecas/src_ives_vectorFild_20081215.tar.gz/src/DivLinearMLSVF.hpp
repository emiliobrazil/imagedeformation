#ifndef __DIVLINEARMLSVF_HPP__

    #define __DIVLINEARMLSVF_HPP__

    #include <cstddef>
    #include <cfloat>

    #include "VectorField.hpp"

    #include "cppblas.hpp"
    #include "cpplapack.hpp"

    template < typename real, unsigned int n, class Kernel >
    class DivLinearMLSVF : public VectorField<real,n> {


        protected:
            unsigned int numberOfSamples;
            real* points;
            real* vectors;

            real divBeta;

            Kernel kernel;
            real radius;

        public:
            DivLinearMLSVF(void);
            DivLinearMLSVF(const DivLinearMLSVF<real,n,Kernel>& vf);
            virtual ~DivLinearMLSVF(void);

            unsigned int getNumberOfSamples(void) const;
            void getPoints(real* points) const;
            void getVectors(real* vectors) const;

            void setSamples(unsigned int numberOfSamples,
                const real* points, const real* vectors);

            real getDivBeta(void) const;
            void setDivBeta(const real divBeta);

            real getRadius(void) const;
            void setRadius(const real radius);

            virtual void evaluate(
                const real point[n],
                real vector[n]
            ) const;

            void clear(void);

            virtual DivLinearMLSVF<real,n,Kernel>& operator=(
                const DivLinearMLSVF<real,n,Kernel>& vf
            );

        private:
            void computeAverages(const real* point,
                unsigned int& nnz, unsigned int* nnzIndices,
                real* weights, real xBar[n], real yBar[n]) const;
            void computeCovariances(unsigned int nnz,
                const unsigned int* nnzIndices, const real* weights,
                const real xBar[n], const real yBar[n],
                real xxBar[n][n], real xyBar[n][n]) const;

    };

    template < typename real, unsigned int n, class Kernel >
    DivLinearMLSVF<real,n,Kernel>::DivLinearMLSVF(void) {
        this->numberOfSamples = 0;
        this->points = NULL;
        this->vectors = NULL;
        this->divBeta = 0;
        this->radius = 1;
    }

    template < typename real, unsigned int n, class Kernel >
    DivLinearMLSVF<real,n,Kernel>::DivLinearMLSVF(
            const DivLinearMLSVF<real,n,Kernel>& vf
    ) {
        (*this) = vf;
    }

    template < typename real, unsigned int n, class Kernel >
    DivLinearMLSVF<real,n,Kernel>::~DivLinearMLSVF(void) {
        this->clear();
    }

    template < typename real, unsigned int n, class Kernel >
    unsigned int DivLinearMLSVF<real,n,Kernel>::getNumberOfSamples(void) const {
        return this->numberOfSamples;
    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::getPoints(real* points) const {
        cppblas_copy(n * this->numberOfSamples, this->points, 1, points, 1);
    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::getVectors(real* vectors) const {
        cppblas_copy(n * this->numberOfSamples, this->vectors, 1, vectors, 1);
    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::setSamples(unsigned int numberOfSamples,
            const real* points, const real* vectors) {
        this->clear();
        this->numberOfSamples = numberOfSamples;
        this->points = new real[n * this->numberOfSamples];
        this->vectors = new real[n * this->numberOfSamples];
        cppblas_copy(n * this->numberOfSamples, points, 1, this->points, 1);
        cppblas_copy(n * this->numberOfSamples, vectors, 1, this->vectors, 1);
    }

    template < typename real, unsigned int n, class Kernel >
    real DivLinearMLSVF<real,n,Kernel>::getDivBeta(void) const {
        return this->divBeta;
    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::setDivBeta(const real divBeta) {
        this->divBeta = divBeta;
    }

    template < typename real, unsigned int n, class Kernel >
    real DivLinearMLSVF<real,n,Kernel>::getRadius(void) const {
        return this->radius;
    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::setRadius(const real radius) {
        this->radius = radius;
    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::evaluate(const real point[n],
            real vector[n]) const {
        static const real EPSILON = std::sqrt(FLT_EPSILON);
        real xBar[n], yBar[n], xxBar[n][n], xyBar[n][n];
        real* weights = new real[this->numberOfSamples];
        unsigned int nnz, *nnzIndices = new unsigned int[this->numberOfSamples];
        this->computeAverages(point, nnz, nnzIndices, weights, xBar, yBar);

        if (nnz > 0) {
            this->computeCovariances(nnz, nnzIndices,
                weights, xBar, yBar, xxBar, xyBar);

            real x[n], tmpVector[n], tmpMatrix[n][n];
            cppblas_copy(n, point, 1, x, 1);
            cppblas_axpy(n, -1, xBar, 1, x, 1);
            cppblas_copy(n, x, 1, tmpVector, 1);
            cppblas_copy(n * n, (real*)xxBar, 1, (real*)tmpMatrix, 1);
            int info = cpplapack_posv(CblasRowMajor, CblasUpper,
                n, 1, (real*)xxBar, n, x, n);
            bool blewUp = false;

            if (info == 0) {
                real normInvAx = cppblas_nrm2(n, x, 1);
                real normX = cppblas_nrm2(n, tmpVector, 1);
                blewUp = ((EPSILON * normInvAx) > normX);
            }

            if ((info != 0) || blewUp) {
                cppblas_copy(n, tmpVector, 1, x, 1);
                cppblas_copy(n * n, (real*)tmpMatrix, 1, (real*)xxBar, 1);
                real rho = EPSILON * (1 + cppblas_asum(n, (real*)xxBar, n + 1));
                cppatlas_set(n, rho, tmpVector, 1);
                cppblas_axpy(n, 1, tmpVector, 1, (real*)xxBar, n + 1);
                info = cpplapack_posv(CblasRowMajor, CblasUpper,
                    n, 1, (real*)xxBar, n, x, n);

                if (info != 0) {
                    std::cerr << "REGULARIZATION ERROR: DivLinearMLSVF::info = "
                            << info << std::endl;
                }

            }

            cppblas_copy(n * n, (real*)xyBar, 1, (real*)tmpMatrix, 1);
            info = cpplapack_potrs(CblasRowMajor, CblasUpper, n, n,
                (real*)xxBar, n, (real*)xyBar, n);
            info = cpplapack_potri(CblasRowMajor,CblasUpper,n,(real*)xxBar,n);
            real traceXX = 0, traceXY = 0;

            for (register unsigned int i = 0; i < n; ++i) {
                traceXX += xxBar[i][i];
                traceXY += xyBar[i][i];
            }

            real lambda = (this->divBeta - traceXY) / traceXX;
            cppblas_copy(n * n, (real*)tmpMatrix, 1, (real*)xyBar, 1);
            cppatlas_set(n, lambda, tmpVector, 1);
            cppblas_axpy(n, 1, tmpVector, 1, (real*)xyBar, n + 1);
            cppblas_copy(n, yBar, 1, vector, 1);
            cppblas_gemv(CblasRowMajor, CblasTrans,
                n, n, 1, (real*)xyBar, n, x, 1, 1, vector, 1);
        } else {
            cppatlas_set(n, 0, vector, 1);
        }

        delete[] nnzIndices;
        delete[] weights;
    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::clear(void) {

        if (this->vectors != NULL) {
            delete[] this->vectors;
            this->vectors = NULL;
        }

        if (this->points != NULL) {
            delete[] this->points;
            this->points = NULL;
        }

        if (this->numberOfSamples > 0) {
            this->numberOfSamples = 0;
        }

    }

    template < typename real, unsigned int n, class Kernel >
    DivLinearMLSVF<real,n,Kernel>& DivLinearMLSVF<real,n,Kernel>::operator=(
            const DivLinearMLSVF<real,n,Kernel>& vf
    ) {
        this->setSamples(vf.numberOfSamples, vf.points, vf.vectors);
        this->divBeta = vf.divBeta;
        this->radius = vf.radius;
        return (*this);
    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::computeAverages(const real* point,
            unsigned int& nnz, unsigned int* nnzIndices, real* weights,
            real xBar[n], real yBar[n]) const {
        static const real EPSILON = FLT_EPSILON;
        real weightSum = 0;
        nnz = 0;
        cppatlas_set(n, 0, xBar, 1);
        cppatlas_set(n, 0, yBar, 1);

        for (register unsigned int i = 0; i < this->numberOfSamples; ++i) {
            real weight = kernel(&this->points[n * i], point, this->radius);

            if (weight > EPSILON) {
                weightSum += weight;
                nnzIndices[nnz] = i;
                weights[nnz] = weight;
                ++nnz;

                cppblas_axpy(n, weight, &this->points[n * i], 1, xBar, 1);
                cppblas_axpy(n, weight, &this->vectors[n * i], 1, yBar, 1);
            }

        }

        if (weightSum > EPSILON) {
            cppblas_scal(n, 1 / weightSum, xBar, 1);
            cppblas_scal(n, 1 / weightSum, yBar, 1);
            cppblas_scal(nnz, 1 / weightSum, weights, 1);
        }

    }

    template < typename real, unsigned int n, class Kernel >
    void DivLinearMLSVF<real,n,Kernel>::computeCovariances(unsigned int nnz,
            const unsigned int* nnzIndices, const real* weights,
            const real xBar[n], const real yBar[n],
            real xxBar[n][n], real xyBar[n][n]) const {
        cppatlas_set(n * n, 0, (real*)xxBar, 1);
        cppatlas_set(n * n, 0, (real*)xyBar, 1);

        for (register unsigned int i = 0; i < nnz; ++i) {
            real xBarI[n], yBarI[n];
            cppblas_copy(n, &this->points[n * nnzIndices[i]], 1, xBarI, 1);
            cppblas_copy(n, &this->vectors[n * nnzIndices[i]], 1, yBarI, 1);
            cppblas_axpy(n, -1, xBar, 1, xBarI, 1);
            cppblas_axpy(n, -1, yBar, 1, yBarI, 1);
            cppblas_ger(CblasRowMajor, n, n, weights[i],
                xBarI, 1, xBarI, 1, (real*)xxBar, n);
            cppblas_ger(CblasRowMajor, n, n, weights[i],
                xBarI, 1, yBarI, 1, (real*)xyBar, n);
        }

    }

#endif  // __DIVLINEARMLSVF_HPP__
