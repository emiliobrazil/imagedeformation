#ifndef __MLSVF_HPP__

    #define __MLSVF_HPP__

    #include "Kernel.hpp"
    #include "Gaussian.hpp"
    #include "Wendland31.hpp"
    #include "Hong0.hpp"
    #include "Hong1.hpp"
    #include "Hong2.hpp"
    #include "Hong3.hpp"
    #include "VectorField.hpp"
    #include "ConstantVF.hpp"
    #include "LinearVF.hpp"
    #include "QuadraticVF.hpp"
    #include "ConstantMLSVF.hpp"
    #include "LinearMLSVF.hpp"
    #include "DivLinearMLSVF.hpp"
    #include "FourVortices.hpp"
    #include "FourSources.hpp"
    #include "FourGaussians.hpp"

#endif  // __MLSVF_HPP__
