#ifndef __CPPBLAS_HPP__

    #define __CPPBLAS_HPP__

    extern "C" {
        #include <cblas.h>
        #include <atlas_aux.h>
    }

    inline float cppblas_dot(const int N, const float *X, const int incX,
                             const float *Y, const int incY) {
        return cblas_sdot(N, X, incX, Y, incY);
    }

    inline double cppblas_dot(const int N, const double *X, const int incX,
                              const double *Y, const int incY) {
        return cblas_ddot(N, X, incX, Y, incY);
    }

    inline float cppblas_nrm2(const int N, const float *X, const int incX) {
        return cblas_snrm2(N, X, incX);
    }

    inline double cppblas_nrm2(const int N, const double *X, const int incX) {
        return cblas_dnrm2(N, X, incX);
    }

    inline float cppblas_asum(const int N, const float *X, const int incX) {
        return cblas_sasum(N, X, incX);
    }

    inline double cppblas_asum(const int N, const double *X, const int incX) {
        return cblas_dasum(N, X, incX);
    }

    inline void cppblas_copy(const int N, const float *X, const int incX,
                             float *Y, const int incY) {
        cblas_scopy(N, X, incX, Y, incY);
    }

    inline void cppblas_copy(const int N, const double *X, const int incX,
                             double *Y, const int incY) {
        cblas_dcopy(N, X, incX, Y, incY);
    }

    inline void cppatlas_axpby(const int N, const float alpha, const float *X,
                               const int incX, const float beta, float *Y,
                               const int incY) {
//         catlas_saxpby(N, alpha, X, incX, beta, Y, incY);
        ATL_saxpby(N, alpha, X, incX, beta, Y, incY);
    }

    inline void cppatlas_axpby(const int N, const double alpha, const double *X,
                               const int incX, const double beta, double *Y,
                               const int incY) {
//         catlas_daxpby(N, alpha, X, incX, beta, Y, incY);
        ATL_daxpby(N, alpha, X, incX, beta, Y, incY);
    }

    inline void cppblas_axpy(const int N, const float alpha, const float *X,
                             const int incX, float *Y, const int incY) {
        cblas_saxpy(N, alpha, X, incX, Y, incY);
    }

    inline void cppblas_axpy(const int N, const double alpha, const double *X,
                             const int incX, double *Y, const int incY) {
        cblas_daxpy(N, alpha, X, incX, Y, incY);
    }

    inline void cppatlas_set(const int N, const float alpha,
                             float *X, const int incX) {
//         catlas_sset(N, alpha, X, incX);
        ATL_sset(N, alpha, X, incX);
    }

    inline void cppatlas_set(const int N, const double alpha,
                             double *X, const int incX) {
//         catlas_dset(N, alpha, X, incX);
        ATL_dset(N, alpha, X, incX);
    }

    inline void cppblas_scal(const int N, const float alpha,
                             float *X, const int incX) {
        cblas_sscal(N, alpha, X, incX);
    }

    inline void cppblas_scal(const int N, const double alpha,
                             double *X, const int incX) {
        cblas_dscal(N, alpha, X, incX);
    }

    inline void cppblas_gemv(const enum CBLAS_ORDER Order,
                             const enum CBLAS_TRANSPOSE TransA, const int M,
                             const int N, const float alpha, const float *A,
                             const int lda, const float *X, const int incX,
                             const float beta, float *Y, const int incY) {
        cblas_sgemv(Order, TransA, M, N, alpha, A, lda, X, incX, beta, Y, incY);
    }

    inline void cppblas_gemv(const enum CBLAS_ORDER Order,
                             const enum CBLAS_TRANSPOSE TransA, const int M,
                             const int N, const double alpha, const double *A,
                             const int lda, const double *X, const int incX,
                             const double beta, double *Y, const int incY) {
        cblas_dgemv(Order, TransA, M, N, alpha, A, lda, X, incX, beta, Y, incY);
    }

    inline void cppblas_ger(const enum CBLAS_ORDER Order, const int M,
                            const int N, const float alpha, const float *X,
                            const int incX, const float *Y, const int incY,
                            float *A, const int lda) {
        cblas_sger(Order, M, N, alpha, X, incX, Y, incY, A, lda);
    }

    inline void cppblas_ger(const enum CBLAS_ORDER Order, const int M,
                            const int N, const double alpha, const double *X,
                            const int incX, const double *Y, const int incY,
                            double *A, const int lda) {
        cblas_dger(Order, M, N, alpha, X, incX, Y, incY, A, lda);
    }

#endif  // __CPPBLAS_HPP__
