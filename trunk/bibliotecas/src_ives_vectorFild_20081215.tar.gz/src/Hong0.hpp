#ifndef __HONG0_HPP__

    #define __HONG0_HPP__

    template < typename real, unsigned int n >
    class Hong0 {


        protected:
            real epsilon;

        public:
            Hong0(const real epsilon = 1e-4);
            virtual ~Hong0(void);

            virtual real operator()(
                const real point[n],
                const real center[n],
                const real radius
            ) const;

    };

    template < typename real, unsigned int n >
    Hong0<real,n>::Hong0(const real epsilon) {
        this->epsilon = epsilon;
    }

    template < typename real, unsigned int n >
    Hong0<real,n>::~Hong0(void) {
        // Do nothing...
    }

    template < typename real, unsigned int n >
    real Hong0<real,n>::operator()(const real point[n],
            const real center[n], const real radius) const {
        real vector[n];
        cppblas_copy(n, point, 1, vector, 1);
        cppblas_axpy(n, -1, center, 1, vector, 1);
        real r = cppblas_nrm2(n, vector, 1);
        r /= radius;
        return (1 / (r + epsilon));
    }

#endif  // __HONG0_HPP__
