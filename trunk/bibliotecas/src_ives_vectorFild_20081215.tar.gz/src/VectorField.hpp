#ifndef __VECTORFIELD_HPP__

    #define __VECTORFIELD_HPP__

    template < typename real, unsigned int n >
    class VectorField {


        protected:
            VectorField(void) {}

        public:
            virtual ~VectorField(void) {}

            virtual void evaluate(
                const real point[n],
                real vector[n]
            ) const = 0;

    };

#endif  // __VECTORFIELD_HPP__
