#ifndef __CPPLAPACK_HPP__

    #define __CPPLAPACK_HPP__

    extern "C" {
        #include <clapack.h>
    }

    inline int cpplapack_posv(const enum ATLAS_ORDER Order,
                              const enum ATLAS_UPLO Uplo, const int N,
                              const int NRHS, float *A, const int lda,
                              float *B, const int ldb) {
        return clapack_sposv(Order, Uplo, N, NRHS, A, lda, B, ldb);
    }

    inline int cpplapack_posv(const enum ATLAS_ORDER Order,
                              const enum ATLAS_UPLO Uplo, const int N,
                              const int NRHS, double *A, const int lda,
                              double *B, const int ldb) {
        return clapack_dposv(Order, Uplo, N, NRHS, A, lda, B, ldb);
    }

    inline int cpplapack_potrf(const enum ATLAS_ORDER Order,
                               const enum ATLAS_UPLO Uplo,
                               const int N, float *A, const int lda) {
        return clapack_spotrf(Order, Uplo, N, A, lda);
    }

    inline int cpplapack_potrf(const enum ATLAS_ORDER Order,
                               const enum ATLAS_UPLO Uplo,
                               const int N, double *A, const int lda) {
        return clapack_dpotrf(Order, Uplo, N, A, lda);
    }

    inline int cpplapack_potrs(const enum CBLAS_ORDER Order,
                               const enum CBLAS_UPLO Uplo,
                               const int N, const int NRHS, const float *A,
                               const int lda, float *B, const int ldb) {
        return clapack_spotrs(Order, Uplo, N, NRHS, A, lda, B, ldb);
    }

    inline int cpplapack_potrs(const enum CBLAS_ORDER Order,
                               const enum CBLAS_UPLO Uplo,
                               const int N, const int NRHS, const double *A,
                               const int lda, double *B, const int ldb) {
        return clapack_dpotrs(Order, Uplo, N, NRHS, A, lda, B, ldb);
    }

    inline int cpplapack_potri(const enum ATLAS_ORDER Order,
                               const enum ATLAS_UPLO Uplo,
                               const int N, float *A, const int lda) {
        return clapack_spotri(Order, Uplo, N, A, lda);
    }

    inline int cpplapack_potri(const enum ATLAS_ORDER Order,
                               const enum ATLAS_UPLO Uplo,
                               const int N, double *A, const int lda) {
        return clapack_dpotri(Order, Uplo, N, A, lda);
    }

#endif  // __CPPLAPACK_HPP__
